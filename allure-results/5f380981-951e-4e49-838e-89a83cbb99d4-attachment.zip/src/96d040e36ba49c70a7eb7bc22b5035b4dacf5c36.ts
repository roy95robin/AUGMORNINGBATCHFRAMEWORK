import { expect, test } from "@playwright/test";
import { CartPage } from "../pages/cartPage";
import { dashboardPage } from "../pages/dashboardPage";
import { LoginPage } from "../pages/loginPage";
import loginData from "../testdata/login.json";
import products from "../testdata/product.json";

const product = products[0];
let loginPage: LoginPage;

let cartPage: CartPage;

test.beforeEach(async ({ page }) => {
    loginPage = new LoginPage(page);
  
    cartPage = new CartPage(page);
    await loginPage.launchUrl(loginData.url);
    await loginPage.loginIntoApplication(loginData.email, loginData.password);
});

test("cart displays the selected product and allows checkout", async ({ page }) => {
    
    await expect(cartPage.productItem(product.productName)).toBeVisible();
    await cartPage.proceedToCheckout();
});
